package ut.ee.cs.ha_j_list

import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Filter
import androidx.core.content.ContextCompat.startActivity


import kotlin.collections.ArrayList
import kotlinx.android.synthetic.main.data.view.*


class adapter(val context: Context, val list: ArrayList<Contact>):BaseAdapter() {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {



        val view:View =LayoutInflater.from(context).inflate(R.layout.data,parent,false)
        view.name.text=list[position].name
        view.numberxxxx.text=list[position].phoneNumber
        view.emailxxxx.text=list[position].email

        view.sendxx.setOnClickListener {
            val intentSend= view.emailxxxx.text
            val intent = Intent(view.context, GO_email::class.java)
            intent.putExtra("email_of", "$intentSend")
            startActivity(view.context,intent,null);

        }
        return  view
            }

    override fun getItem(position: Int): Any {
       return list[position]

    }

    override fun getItemId(position: Int): Long {
      return  position.toLong()
    }

    override fun getCount(): Int {
        return list.size
    }

}