package ut.ee.cs.ha_j_list

import android.Manifest
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract
import android.util.Log
import android.widget.SearchView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {


    val  checkPerm= 1
    var ListofCon=ArrayList<Contact>()
    lateinit var queryxx: String
    lateinit var adapter: adapter



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        fun searching(search: SearchView) {
            search.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
                override fun onQueryTextSubmit(query: String?): Boolean {
                    queryxx=query!!
                    Log.i("da","$queryxx")



                    return false
                }

                override fun onQueryTextChange(newText: String): Boolean {
                    queryxx=newText
                    Log.i("danew","queryxx")


                    when {

                        queryxx.isNotEmpty()->
                        {


                        queryAdapterFiltered()



                        }
                        queryxx.isEmpty() -> {

                          queryAda()
                            if (queryxx.isEmpty()){
                                queryAdapter()
                            }


                        }



                    }






                    return true
                }



            })


        }




        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CONTACTS),checkPerm)
        }
        else{
         queryAdapter()






        }




        searching(sea)

    }



fun queryAdapterFiltered(){
    adapter =adapter(this,FilteredList())
    list.adapter = adapter
    adapter.notifyDataSetChanged()


}

    fun someThingWrong(){
        Toast.makeText(this,"Try again",Toast.LENGTH_LONG).show()
    }
    fun queryAda(){

        var contactss =  ArrayList<Contact>()

        adapter =adapter(this,contactss)
        list.adapter = adapter
        adapter.notifyDataSetChanged()
    }

    fun queryAdapter(){
        adapter =adapter(this,Data())
        list.adapter = adapter



    }


    fun Data(): ArrayList<Contact> {

        val Cursor=contentResolver.query(ContactsContract.Contacts.CONTENT_URI,null,null,null,null)
        if ((Cursor?.count ?:0)>0){
            while (Cursor !=null && Cursor.moveToNext()) {
                var email = ""
                var phone = ""
                val ID = Cursor.getString(Cursor.getColumnIndex(ContactsContract.Contacts._ID))

                val Name =
                    Cursor.getString(Cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME))




                if (Cursor.getInt(Cursor.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER)) > 0) {
                    val phoneCurs = contentResolver.query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        null,
                        ContactsContract.CommonDataKinds.Phone.CONTACT_ID + "=?",
                        arrayOf<String>(ID),
                        null

                    )
                    while (phoneCurs!!.moveToNext()) {
                        phone += phoneCurs.getString(phoneCurs.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)) + "\n"
                    }
                    phoneCurs.close()
                }

                val emailCurs = contentResolver.query(
                    ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                    null,
                    ContactsContract.CommonDataKinds.Email.CONTACT_ID + "=?",
                    arrayOf<String>(ID),
                    null
                )
                while (emailCurs!!.moveToNext()) {
                    email += emailCurs.getString(emailCurs.getColumnIndex(ContactsContract.CommonDataKinds.Email.DATA)) + "\n"
                }
                emailCurs.close()
                ListofCon.add(Contact(Name, phone, email))
            }

        }
        Cursor!!.close()



        return ListofCon

    }

    private fun FilteredList(): ArrayList<Contact> {
        val arrayList=ArrayList<Contact>()
        val cursor=contentResolver.query(ContactsContract.Contacts.CONTENT_URI,null,null,null,null)
        if ((cursor?.count ?:0)>0){
            while (cursor !=null && cursor.moveToNext()){
                val ID=cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID))
                val Name=cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME))
                var phone=""
                if (cursor.getInt(cursor.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))>0){
                    val phoneNumberCursor=contentResolver.query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        null,
                        ContactsContract.CommonDataKinds.Phone.CONTACT_ID+"=?",
                        arrayOf<String>(ID),
                        null

                    )
                    while (phoneNumberCursor!!.moveToNext()){
                        phone +=phoneNumberCursor.getString(
                            phoneNumberCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                        )+"\n"
                    }
                    phoneNumberCursor.close()
                }
                var emailaddress =""
                val emailCursor=contentResolver.query(
                    ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                    null,
                    ContactsContract.CommonDataKinds.Email.CONTACT_ID+"=?",
                    arrayOf<String>(ID),
                    null

                )
                while (emailCursor!!.moveToNext()){
                    emailaddress=emailCursor.getString(
                        emailCursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.DATA)

                    )+"\n"
                }
                emailCursor.close()


                if (queryxx==Name)     {
                    arrayList.add(Contact(Name,phone,emailaddress))
                }
                else someThingWrong()


               }


        }
        cursor!!.close()

        return arrayList

    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>,grantResults: IntArray)
    {
        if (requestCode==checkPerm)
        {
            val adapter =adapter(this,Data())
            list.adapter = adapter
        }
    }




}
