package ut.ee.cs.ha_j_list

data class Contact(
    val name: String,
    val phoneNumber: String,
    val email: String
)

